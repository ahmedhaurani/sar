<div>
    <div class="card">
        <img src="<?php echo e(asset('storage/'.$candidate->photo)); ?>" class="card-img-top" alt="Candidate Photo">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($candidate->name); ?></h5>
            <p class="card-text"><?php echo e($candidate->cv); ?></p>
            <p class="text-muted">Governorate: <?php echo e($candidate->governorate->name); ?></p>
            <p class="text-muted">Status: <?php echo e($candidate->active ? 'Active' : 'Inactive'); ?></p>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\candidate\view-candidate.blade.php ENDPATH**/ ?>