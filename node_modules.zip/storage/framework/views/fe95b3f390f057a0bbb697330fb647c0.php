<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4>تعديل</h4>
        </div>

        <div class="card-body">
            <!-- Success Message -->
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>

            <form wire:submit.prevent="update">
                <!-- Candidate Name -->
                <div class="form-group mb-3">
                    <label for="name" class="form-label">الاسم</label>
                    <input type="text" wire:model="name" class="form-control" id="name"
                        placeholder="ادخل الاسم">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Candidate Photo -->
                <div class="form-group mb-3">
                    <label for="photo" class="form-label">الصورة</label>
                    <input type="file" wire:model="photo" class="form-control-file" id="photo">
                    <?php if($photo): ?>
                    <img src="<?php echo e($photo->temporaryUrl()); ?>" alt="<?php echo e($name); ?>" class="img-thumbnail mt-2" width="150">
                    <?php elseif($currentPhoto): ?>
                    <!-- Check if the current photo exists -->
                    <img src="<?php echo e(asset('storage/' . $currentPhoto)); ?>" alt="<?php echo e($name); ?>" class="img-thumbnail mt-2"
                        width="150">
                    <?php endif; ?>
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Candidate CV -->
                
                

                


                


                

                  <div class="mb-3">
                    <label class="form-label" for="inputEmail"></label>
                    <!-- Custom Toolbar -->


                    <!-- Quill Editor -->
                    <div id="quill-container" wire:ignore>
                        <div id="quill-editor" class="mb-3" style="height: 300px;"></div>
                    </div>

                    <!-- Hidden textarea for Livewire binding -->
                    <textarea
                        rows="3"
                        class="mb-3 d-none"
                        name="body"
                        id="quill-editor-area"
                        wire:model.defer="cv"></textarea>

                    <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <!-- Governorate -->
                <div class="form-group mb-3">
                    <label for="governorate_id" class="form-label">المحافظة</label>
                    <select wire:model="governorate_id" class="form-control" id="governorate_id">
                        <option value="">اختر المحافظة</option>
                        <?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gov->id); ?>" <?php echo e($gov->id == $governorate_id ? 'selected' : ''); ?>>
                                <?php echo e($gov->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['governorate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <!-- Active Status -->
                <div class="form-check mb-3">
                    <input type="checkbox" wire:model="is_active" class="form-check-input" id="is_active">
                    <label class="form-check-label" for="is_active">Active</label>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary mt-3">تحديث</button>
                <a href="<?php echo e(route('admin.candidates.index')); ?>" class="btn btn-secondary mt-3">الرجوع</a>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#cv').summernote({
            placeholder: 'Enter CV...',
            tabsize: 2,
            height: 300,
            callbacks: {
                onChange: function(contents, $editable) {
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('cv', contents);
                }
            }
        });
    });
</script>
<script type="text/javascript">
const toolbarOptions = [
    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
    // [{ 'font': [] }],

  ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
  [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
  ['blockquote', 'code-block'],
  [{ 'align': [] }],
  [{ 'direction': 'rtl' }],                         // text direction


  [{ 'list': 'ordered'}, { 'list': 'bullet' }],
  [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
  [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent

//   [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown



  ['clean']                                         // remove formatting button
];
    document.addEventListener('DOMContentLoaded', function() {
        if (document.getElementById('quill-editor-area')) {
            var editor = new Quill('#quill-editor', {

                modules: {
    toolbar: toolbarOptions
  },
                theme:'snow'
            });

            var quillEditorArea = document.getElementById('quill-editor-area');

            // Set initial content from the textarea (useful for editing existing content)
            editor.root.innerHTML = quillEditorArea.value;

            // Sync Quill editor changes to the hidden textarea
            editor.on('text-change', function() {
                quillEditorArea.value = editor.root.innerHTML;
                // Use Livewire to update the value
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('cv', quillEditorArea.value);
            });

            // Optional: sync textarea changes to the Quill editor (e.g., when loaded via Livewire)
            quillEditorArea.addEventListener('input', function() {
                editor.root.innerHTML = quillEditorArea.value;
            });

            // Handle Livewire updates (for example, when editing)
            window.addEventListener('load-cv-content', event => {
                editor.root.innerHTML = event.detail.content;
                quillEditorArea.value = event.detail.content;
            });
        }
    });
</script>



<?php $__env->stopPush(); ?>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\candidate\edit-candidate.blade.php ENDPATH**/ ?>