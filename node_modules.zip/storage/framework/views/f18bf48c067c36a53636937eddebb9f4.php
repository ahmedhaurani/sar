<div class="container mt-3">
    <h3>Manage Permissions for Role: <?php echo e($role->name); ?></h3>

    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <form wire:submit.prevent="save">
        <div class="row">
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-3 col-xl-2 mb-3">
                    <div class="form-check">
                        <input
                            type="checkbox"
                            class="form-check-input"
                            id="permission-<?php echo e($permission->id); ?>"
                            value="<?php echo e($permission->id); ?>"
                            wire:model="selectedPermissions"
                            <?php echo e(in_array($permission->id, $selectedPermissions) ? 'checked' : ''); ?>

                        >
                        <label class="form-check-label" for="permission-<?php echo e($permission->id); ?>">
                            <?php echo e($permission->name); ?>

                        </label>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Save Permissions</button>
        </div>
    </form>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\roles\add-permissions-to-role.blade.php ENDPATH**/ ?>