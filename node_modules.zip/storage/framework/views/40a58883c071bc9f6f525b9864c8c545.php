<div>
    <!-- Top Navigation Buttons -->
    <div class="container mt-5">
        <a href="<?php echo e(url('roles')); ?>" class="btn btn-outline-primary mx-1"><i class="fas fa-users"></i> Roles</a>
        <a href="<?php echo e(url('permissions')); ?>" class="btn btn-outline-info mx-1"><i class="fas fa-key"></i> Permissions</a>
        <a href="<?php echo e(url('users')); ?>" class="btn btn-outline-warning mx-1"><i class="fas fa-user"></i> Users</a>
    </div>

    <!-- Permission Table -->
    <div class="container mt-3">
        <!-- Status Alert -->
        <?php if(session('status')): ?>
        <div class="alert alert-primary alert-dismissible fade show mt-3" role="alert">
            <i class="fas fa-check-circle"></i> <?php echo e(session('status')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card shadow-sm">


            <div class="card-header text-white d-flex justify-content-between align-items-center">

                <h4 class="mb-0"><i class="fas fa-key"></i> الصلاحيات والاذونات</h4>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create permission')): ?>
                <button wire:click="resetFields" data-bs-toggle="modal" data-bs-target="#permissionModal"
                    class="btn btn-light">
                    <i class="fas fa-plus-circle"></i> إضافة صلاحية جديدة
                </button>
                <?php endif; ?>
            </div>
            <div class="card-body">

                <!-- Permissions Table -->
                <table class="table table-bordered table-striped mt-3">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>الاسم</th>
                            <th width="40%">الإجراء</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($permission->id); ?></td>
                            <td><?php echo e($permission->name); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update permission')): ?>
                                <button wire:click="edit(<?php echo e($permission->id); ?>)" class="btn btn-sm btn-success"
                                    data-bs-toggle="modal" data-bs-target="#permissionModal">
                                    <i class="fas fa-edit"></i> تعديل
                                </button>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete permission')): ?>
                                <button wire:click="confirmDelete(<?php echo e($permission->id); ?>)"
                                    class="btn btn-sm btn-danger mx-2" data-bs-toggle="modal"
                                    data-bs-target="#modalCenter">
                                    <i class="fas fa-trash"></i> حذف
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="permissionModal" tabindex="-1" aria-labelledby="permissionModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="permissionModalLabel"><?php echo e($permissionId ? 'تعديل' : 'إضافة'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="<?php echo e($permissionId ? 'update' : 'store'); ?>">
                        <div class="mb-3">
                            <label for="name" class="form-label">اسم الصلاحيات</label>
                            <input type="text" wire:model="name" class="form-control"
                                placeholder="Enter permission name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary"><?php echo e($permissionId ? 'Update' : 'Create'); ?>

                                الصلاحيات</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->

    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalCenterTitle">تأكيد الحذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <p>هل انت متأكد من انك تريد حذف هذه الصلاحية ؟ </p>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">اغلاق</button>
                    <button type="button" class="btn btn-primary" wire:click="deleteConfirmed">حذف</button>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
    <?php
        $__scriptKey = '1316464165-0';
        ob_start();
    ?>
<script>
    $wire.on('closeDeleteModal', () => {

      $('#deleteConfirmModal').modal('hide');
      $('.modal').remove();
      $('.modal-backdrop').remove();
      $('body').removeClass('modal-open');
      $('body').removeAttr('style');
    });

    $wire.on('closeUpdateModal', () => {

$('#permissionModal').modal('hide');
$('.modal').remove();
$('.modal-backdrop').remove();
$('body').removeClass('modal-open');
$('body').removeAttr('style');
});

</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

<?php $__env->stopPush(); ?>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\permission-controller.blade.php ENDPATH**/ ?>