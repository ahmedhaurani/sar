<div class="container mt-4 bg-white p-4 rounded shadow-sm">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-4">
                <div class="card shadow-sm border-light">
                    <div class="row g-0">
                        <!-- Candidate Image -->
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('storage/'.$candidate->photo)); ?>" alt="Candidate Photo" class="img-fluid rounded-start">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <!-- Candidate Name -->
                                <h5 class="card-title"><?php echo e($candidate->name); ?></h5>

                                <!-- Candidate CV -->
                                <p class="card-text"><?php echo e($candidate->cv); ?></p>

                                <!-- Vote Count -->
                                <p class="text-muted">Total Votes: <?php echo e($candidate->totalVotes); ?></p>

                                <!-- Like/Dislike Buttons -->
                                <div class="d-flex mb-2">
                                    
                                </div>

                                <!-- Vote Button -->
                                <div class="mt-3">
                                    <button wire:click="vote(<?php echo e($candidate->id); ?>)" class="btn btn-success">
                                        Vote
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\candidates.blade.php ENDPATH**/ ?>