
<?php
    $prefix = $prefix ?? '';
?>

<option value="<?php echo e($department['id']); ?>"><?php echo e($prefix . $department['name']); ?></option>

<?php if(isset($department['children'])): ?>
    <?php $__currentLoopData = $department['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('partials.department-option', ['department' => $child, 'prefix' => $prefix . '>> '], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\department\department-option.blade.php ENDPATH**/ ?>