<div>
    <p>Are you sure you want to delete this candidate?</p>
    <button wire:click="delete" class="btn btn-danger">Delete</button>
    <a href="<?php echo e(route('admin.candidates.index')); ?>" class="btn btn-secondary">Cancel</a>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\candidate\delete-candidate.blade.php ENDPATH**/ ?>