<div class="container mt-5">
    <a href="<?php echo e(url('roles')); ?>" class="btn btn-primary mx-1">Roles</a>
    <a href="<?php echo e(url('permissions')); ?>" class="btn btn-info mx-1">Permissions</a>
    <a href="<?php echo e(url('users')); ?>" class="btn btn-warning mx-1">Users</a>
</div>

<div class="container mt-2">
    <div class="row">
        <div class="col-md-12">

            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <div class="card mt-3">
                <div class="card-header">
                    <h4>
                        Roles
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                        <a href="<?php echo e(url('roles/create')); ?>" class="btn btn-primary float-end">Add Role</a>
                        <?php endif; ?>
                    </h4>
                </div>
                <div class="card-body">

                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th width="40%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($role->id); ?></td>
                                <td><?php echo e($role->name); ?></td>
                                <td>
                                    <a href="<?php echo e(url('roles/'.$role->id.'/give-permissions')); ?>" class="btn btn-warning">
                                        Add / Edit Role Permission
                                    </a>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update role')): ?>
                                    <a href="<?php echo e(url('roles/'.$role->id.'/edit')); ?>" class="btn btn-success">
                                        Edit
                                    </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                                    <a href="<?php echo e(url('roles/'.$role->id.'/delete')); ?>" class="btn btn-danger mx-2">
                                        Delete
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\sar_website\resources\views\role-permission\role\index.blade.php ENDPATH**/ ?>