<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?php echo e($settings->description ?? 'Default description'); ?>">
  <meta name="keywords" content="<?php echo e($settings->title ?? 'Default keywords'); ?>">
  <meta name="author" content="<?php echo e($settings->title ?? 'Default author'); ?>">
  <title><?php echo e($settings->title ?? 'Default Title'); ?></title>

  
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('style/assets/vendor/css/rtl/core.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style/assets/vendor/css/rtl/theme-semi-dark.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/demo.css')); ?>">
  <?php if($settings && $settings->favicon): ?>
  <link rel="icon" href="<?php echo e(asset('storage/' . $settings->favicon)); ?>" type="image/x-icon">
<?php endif; ?>


  <style>
    body {
      font-family: 'Tajawal', sans-serif;
      background-color: #F4F6F9;
      color: #333333;
    }

    /* Header */
    .header {
      background: linear-gradient(135deg, #4A90E2, #50E3C2);
      color: #ffffff;
      padding: 20px 0;
      text-align: center;
    }
    .header h1 {
      font-size: 3rem;
      font-weight: 600;
      margin-bottom: 10px;
    }
    .header p {
      font-size: 1.2rem;
      font-weight: 400;
    }
    .logo {
  max-width: 300px; /* Adjust max width as needed */
  margin: 0 auto;
}

.logo img {
  width: 50%;
  height: auto; /* Maintain aspect ratio */
}

.subtitle {
  margin-top: 10px;
  font-size: 1.2rem;
  color: #666;
}
    /* Navbar */
    .navbar {
      background-color: #283E4A;
      /* padding: 1rem 0; */
    }
    .navbar-brand {
      font-size: 1.5rem;
      font-weight: 600;
      color: #ffffff;
    }
    .nav-link {
      color: #ffffff !important;
      font-size: 1rem;
      margin-right: 20px; /* Changed to margin-right for RTL */
    }
    .nav-link:hover {
      color: #50E3C2 !important;
      transition: color 0.3s ease;
    }

    /* Content Section */
    .content-section {
      padding: 60px 0;
      text-align: center;
    }
    .content-section h2 {
      font-size: 2.5rem;
      font-weight: 600;
      color: #333333;
      margin-bottom: 20px;
    }
    .content-section p {
      font-size: 1.1rem;
      color: #666666;
      max-width: 700px;
      margin: 0 auto;
    }

    /* Services Section */
    .services-section {
      padding: 60px 0;
      background-color: #ffffff;
    }
    .services-section h2 {
      font-size: 2.5rem;
      font-weight: 600;
      margin-bottom: 40px;
      text-align: center;
      color: #333333;
    }
    .service-card {
      background-color: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      transition: transform 0.3s ease;
    }
    .service-card:hover {
      transform: translateY(-10px);
    }
    .service-card i {
      font-size: 3rem;
      color: #4A90E2;
      margin-bottom: 20px;
    }
    .service-card h4 {
      font-size: 1.5rem;
      margin-bottom: 15px;
      font-weight: 600;
    }
    .service-card p {
      font-size: 1rem;
      color: #666666;
    }
    .service-card .btn-primary {
      margin-top: 20px;
      background-color: #4A90E2;
      border: none;
      padding: 10px 20px;
    }
    .service-card .btn-primary:hover {
      background-color: #50E3C2;
    }

    /* Footer */
    footer {
      background-color: #283E4A;
      color: #ffffff;
      padding: 40px 0;
      text-align: center;
    }
    footer a {
      color: #50E3C2;
      text-decoration: none;
    }
    footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <!-- Header Section -->
  <header class="header">
    <div class="logo">
        <?php if($settings && $settings->logo): ?>
        <img src="<?php echo e(asset('storage/'.$settings->logo)); ?>" alt="<?php echo e($settings->title); ?>" class="img-fluid">
        <?php endif; ?>
          </div>
      <!-- Optional subtitle if needed -->
  </header>

  <nav class="navbar navbar-expand-lg">
    <div class="container">
        <?php if($settings && $settings->website_name): ?>
      <a class="navbar-brand" href="/"><?php echo e($settings->website_name); ?></a>
      <?php endif; ?>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="تبديل التنقل">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('index')); ?>"><i class="fas fa-home"></i> الرئيسية</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('send_request')); ?>"><i class="fas fa-tags"></i> ارسال طلب</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><i class="fas fa-envelope"></i> اتصل بنا</a>
          </li>

          <!-- Check if the user is authenticated -->
          <?php if(auth()->guard()->check()): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?>

            </a>
            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="fas fa-user-circle"></i> عرض الملف الشخصي</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('user-request')); ?>"><i class="fas fa-user-circle"></i>الطلبات</a></li>

                <li><a class="dropdown-item" href="#"
                     onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                  <i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
              </li>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                  <?php echo csrf_field(); ?>
              </form>
            </ul>
          </li>
          <?php endif; ?>

          <!-- If the user is a guest -->
          <?php if(auth()->guard()->guest()): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('register')); ?>"><i class="fas fa-user-plus"></i> إنشاء حساب</a>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
</nav>

  <!-- Content Section -->
  

  <!-- Services Section -->
  
<?php echo e($slot); ?>

  <!-- Footer -->
  <footer class="mt-5">
    <div class="container">
      <p>&copy; 2024 اسم العلامة التجارية. جميع الحقوق محفوظة.</p>
      
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH D:\laravel\sar_website\resources\views\components\layouts\app.blade.php ENDPATH**/ ?>