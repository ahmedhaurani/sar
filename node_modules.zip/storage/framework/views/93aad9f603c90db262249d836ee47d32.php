<div class="container mt-4 bg-white p-4 rounded shadow-sm">
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="container mt-4">
        <!-- Toggle Filter Button -->
        <div>
            <div class="mb-3">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                            </div>
                            <span class="input-group-text cursor-pointer" id="password2">
                                <i class="fas fa-search"></i>
                            </span>
                            <input type="text" wire:model.live="search" class="form-control" placeholder="البحث بالاسم...">
                        </div>
                    </div>

                    <!-- Governorate Filter -->
                    <div class="col-md-4 mb-3">
                        <select wire:model.live="selectedGovernorate" class="form-control">
                            <option value="">كل المحافظات</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($governorate->id); ?>"><?php echo e($governorate->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Check if there are candidates -->
    <!--[if BLOCK]><![endif]--><?php if($candidates->isEmpty()): ?>
        <div class="alert alert-warning">
            لا توجد نتائج.
        </div>
    <?php else: ?>
        <div class="row">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-3 mb-4">
                    <div class="card shadow-sm h-100">
                        <!-- Candidate Image -->
                        <img src="<?php echo e(asset('storage/'.$candidate->photo)); ?>" alt="Candidate Photo"
                             class="card-img-top img-fluid" style="height: 200px; object-fit: cover;">

                        <!-- Card Body -->
                        <div class="card-body d-flex flex-column">
                            <!-- Candidate Name -->
                            <h5 class="card-title"><?php echo e($candidate->name); ?></h5>

                            <!-- Vote Count -->
                            <p class="text-muted mb-3">مجموع الاصوات: <?php echo e($candidate->totalVotes); ?></p>

                            <!-- Buttons (View CV, Vote) -->
                            <div class="mt-auto">
                                <button class="btn btn-info btn-sm mb-2 w-100" data-bs-toggle="modal"
                                        data-bs-target="#cvModal<?php echo e($candidate->id); ?>">
                                    السيرة الذاتية
                                </button>

                                <button wire:click="vote(<?php echo e($candidate->id); ?>)" class="btn btn-success btn-sm w-100">
                                    التصويت
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- CV Modal -->
                <div class="modal fade" id="cvModal<?php echo e($candidate->id); ?>" tabindex="-1"
                     aria-labelledby="cvModalLabel<?php echo e($candidate->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="cvModalLabel<?php echo e($candidate->id); ?>">السيرة الذاتية للسيد\ة <?php echo e($candidate->name); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p><?php echo $candidate->cv; ?></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <!-- Pagination Links -->
        <div class="d-flex justify-content-center mt-4">
            
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\laravel\sar_website\resources\views/livewire/candidates.blade.php ENDPATH**/ ?>