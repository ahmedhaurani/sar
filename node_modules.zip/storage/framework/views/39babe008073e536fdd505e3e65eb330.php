<div class="container mt-5">


<div class="card mt-5">
    <!-- Back Button -->

    <div class="container mt-5">
        <!-- Back Button -->
        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-primary">
            <i class="fas fa-arrow-left"></i> الرجوع
        </a>
    </div>

    <!-- Status Alert -->
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <i class="fas fa-check-circle"></i> <?php echo e(session('status')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="container mt-4">
        <div class="card shadow-sm">
            <!-- Card Header -->
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-edit"></i> Edit Role</h4>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <!-- Form for Editing Role -->
                <form wire:submit.prevent="update">
                    <!-- Role Name Input -->
                    <div class="mb-3">
                        <label for="name" class="form-label">Role Name</label>
                        <input type="text" id="name" wire:model="name" class="form-control" placeholder="Enter role name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Update Button -->
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-sync-alt"></i> تحديث
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\roles\edit-role.blade.php ENDPATH**/ ?>