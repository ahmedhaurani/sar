<div class="container mt-3">
    <?php if(session('status')): ?>
    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

    <div class="card" >

    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> الرجوع
            </a>
            <h3 class="mb-0">إضافة الصلاحيات والاذونات الى : <?php echo e($role->name); ?></h3>
        </div>


    <div class="row">
        <!-- Available Permissions Column -->
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Available Permissions</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group mt-2">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!in_array($permission->id, $selectedPermissions)): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?php echo e($permission->name); ?>

                                    <button
                                        class="btn btn-primary btn-sm"
                                        wire:click="addPermission(<?php echo e($permission->id); ?>)"
                                    >
                                        إضافة
                                    </button>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Assigned Permissions Column -->
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Assigned Permissions</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group mt-2">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($permission->id, $selectedPermissions)): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?php echo e($permission->name); ?>

                                    <button
                                        class="btn btn-danger btn-sm"
                                        wire:click="removePermission(<?php echo e($permission->id); ?>)"
                                    >
                                        حذف
                                    </button>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\roles\manage-role-permissions.blade.php ENDPATH**/ ?>