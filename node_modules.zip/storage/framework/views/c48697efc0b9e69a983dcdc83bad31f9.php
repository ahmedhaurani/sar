<div class="container mt-4">

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <!-- Card Header (Optional) -->
        

        <!-- Card Body -->
        <div class="card-body">
            <form wire:submit.prevent="submitRequest">
                <!-- Parent Department Dropdown -->
                <div class="mb-4">
                    <label for="parentDepartment" class="form-label fw-bold">القســم</label>
                    <select wire:model.live="selectedParentDepartment" class="form-select" id="parentDepartment">
                        <option value="">اختر القسم</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['selectedParentDepartment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Sub-Department Dropdown -->
                <?php if(!empty($subDepartments) && count($subDepartments) > 0): ?>
                    <div class="mb-4">
                        <label for="subDepartment" class="form-label fw-bold">القسم الفرعي</label>
                        <select wire:model.live="selectedSubDepartment" class="form-select" id="subDepartment">
                            <option value="">اختر القسم الفرعي</option>
                            <?php $__currentLoopData = $subDepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subDepartment->id); ?>"><?php echo e($subDepartment->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['selectedSubDepartment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>

                <!-- Sub-Sub-Department Dropdown -->
                <?php if(!empty($subSubDepartments) && count($subSubDepartments) > 0): ?>
                    <div class="mb-4">
                        <label for="subSubDepartment" class="form-label fw-bold">اختر القسم الفرعي </label>
                        <select wire:model="selectedSubSubDepartment" class="form-select" id="subSubDepartment">
                            <option value="">اختر القسم الفرعي</option>
                            <?php $__currentLoopData = $subSubDepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subSubDepartment->id); ?>"><?php echo e($subSubDepartment->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['selectedSubSubDepartment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>

                <!-- Phone Number Field -->
                <div class="mb-4">
                    <label for="phone_number" class="form-label fw-bold">رقم الهاتف</label>
                    <input wire:model="phone_number" type="text" class="form-control" id="phone_number">
                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Request Title Field -->
                <div class="mb-4">
                    <label for="request_title" class="form-label fw-bold">عنوان الطلب</label>
                    <input wire:model="request_title" type="text" class="form-control" id="request_title">
                    <?php $__errorArgs = ['request_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Request Description Field -->
                <div class="mb-4">
                    <label for="request_description" class="form-label fw-bold">وصف الطلب</label>
                    <textarea wire:model="request_description" class="form-control" id="request_description" rows="3" placeholder="ادخل وصف الطلب"></textarea>
                    <?php $__errorArgs = ['request_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Note Field -->
                <div class="mb-4">
                    <label for="note" class="form-label fw-bold">الملاحظات</label>
                    <textarea wire:model="note" class="form-control" id="note" rows="3" placeholder="ادخل ملاحظاتك"></textarea>
                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="attachments" class="form-label fw-bold">الملفات المرفقة</label>
                    <input wire:model="attachments" type="file" class="form-control" id="attachments" multiple>
                    <?php $__errorArgs = ['attachments.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Submit Button -->
                <div class="d-grid gap-2 mb-3">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-paper-plane"></i> ارسال الطلب
                    </button>
                </div>
            </form>
        </div>

        <!-- Card Footer (Optional) -->
        <div class="card-footer text-center">
            <small class="text-muted">Thank you for your request!</small>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\request-form.blade.php ENDPATH**/ ?>