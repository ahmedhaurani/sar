<div class="container mt-5">
    <!-- Success Message -->
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>

    <!-- Create or Edit Governorate Form -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-header bg-success text-white mb-3">
            <h5 class="mb-0"><?php echo e($updateMode ? 'تعديل المحافظة' : 'اضافة محافظة جديدة'); ?></h5>
        </div>
        <div class="card-body">
            <form wire:submit.prevent="<?php echo e($updateMode ? 'update' : 'store'); ?>">
                <div class="form-group">
                    <label for="name">اسم المحافظة</label>
                    <input type="text" wire:model="name" class="form-control" id="name" placeholder="اسم المحافظة">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-success mt-3"><?php echo e($updateMode ? 'تعديل' : 'اضافة'); ?></button>
                    <?php if($updateMode): ?>
                        <button type="button" class="btn btn-secondary mt-3" wire:click="resetInputFields">الغاء</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- List of Governorates -->
    <div class="card shadow-sm border-0 mb-5">
        <div class="card-header bg-info text-white mb-3">
            <h5 class="mb-0">جميع المحافظات</h5>
        </div>
        <div class="card-body">
            <table class="table table-hover table-striped">
                <thead class="thead-light">
                    <tr>
                        <th>ID</th>
                        <th>الاسم</th>
                        <th>الاجراء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($governorate->id); ?></td>
                            <td><?php echo e($governorate->name); ?></td>
                            <td>
                                <button wire:click="edit(<?php echo e($governorate->id); ?>)" class="btn btn-warning btn-sm">تعديل</button>
                                <button wire:click="confirmDelete(<?php echo e($governorate->id); ?>)"
                                    class="btn btn-sm btn-danger mx-2" data-bs-toggle="modal"
                                    data-bs-target="#confirmModal">
                                    <i class="fas fa-trash"></i> حذف
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div wire:ignore.self class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header py text-white">
                    <h5 class="modal-title" id="confirmModalLabel"> تأكيد الحذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>
                <div class="modal-body">
                  هل انت متأكد من انك تريد حذف محافظة  <?php echo e($governorate->name); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">الغاء</button>
                    <button type="button" wire:click="delete" class="btn btn-danger" data-dismiss="modal">نعم</button>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
    <?php
        $__scriptKey = '2026728055-0';
        ob_start();
    ?>
<script>
    $wire.on('openModal', () => {

      $('#confirmModal').modal('open');
      $('.modal').remove();
      $('.modal-backdrop').remove();
      $('body').removeClass('modal-open');
      $('body').removeAttr('style');
    });

    $wire.on('closeModal', () => {

$('#confirmModal').modal('hide');
$('.modal').remove();
$('.modal-backdrop').remove();
$('body').removeClass('modal-open');
$('body').removeAttr('style');
});

</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

<?php $__env->stopPush(); ?>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\governorate-manage.blade.php ENDPATH**/ ?>