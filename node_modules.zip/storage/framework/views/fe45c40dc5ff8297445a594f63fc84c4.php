<div class="container">
    <!-- Filter Section -->
    <div class="card shadow-sm mb-4">
        <div class="card-header">
            <h5 class="mb-0">تصفية المرشحين</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Search by Name -->
                <div class="col-md-4">
                    <input type="text" wire:model.live="search" class="form-control" placeholder="البحث بالاسم...">
                </div>

                <!-- Governorate Filter -->
                <div class="col-md-4">
                    <select wire:model.live="selectedGovernorate" class="form-control">
                        <option value="">كل المحافظات</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($governorate->id); ?>"><?php echo e($governorate->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>

                <!-- Per Page Selector -->
                
            </div>
        </div>
    </div>

    <!-- Candidates Table Section -->
    <div class="card shadow-sm">
        <div class="card-header">
            <h5 class="mb-0">قائمة المرشحين</h5>
        </div>                                    <a href="<?php echo e(route('admin.candidates.create')); ?>" class="btn btn-info btn-sm">عرض</a>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>الصورة</th>
                            <th>الاسم</th>
                            <th>المحافظة</th>
                            <th>عدد الأصوات</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img src="<?php echo e(asset('storage/'.$candidate->photo)); ?>" alt="صورة المرشح" class="img-thumbnail" style="width: 50px;">
                                </td>
                                <td><?php echo e($candidate->name); ?></td>
                                <td><?php echo e($candidate->governorate->name ?? 'غير متوفر'); ?></td>
                                <td><?php echo e($candidate->totalVotes); ?></td>
                                <td><?php echo e($candidate->active ? 'نشط' : 'غير نشط'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.candidates.edit', $candidate->id)); ?>" class="btn btn-warning btn-sm">تعديل</a>
                                    <a href="<?php echo e(route('admin.candidates.delete', $candidate->id)); ?>" class="btn btn-danger btn-sm">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

            <!-- Pagination Links -->
            <div class="d-flex justify-content-center">
                <?php echo e($candidates->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views/livewire/admin/candidate/view-all-candidates.blade.php ENDPATH**/ ?>