<div class="container">
    <!-- Success Message -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Form Card -->
    <div class="card shadow-sm">
        <div class="card-header">
            <h5 class="mb-0">اضف مرشح جديد</h5>
        </div>
        <div class="card-body">
            <form wire:submit.prevent="save">
                <!-- Name Field -->
                <div class="form-group mb-3">
                    <label for="name">الاسم</label>
                    <input type="text" wire:model="name" class="form-control" id="name" placeholder="ادخل الاسم">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Photo Upload Field -->
                <div class="form-group mb-3">
                    <label for="photo">الصورة</label>
                    <input type="file" wire:model="photo" class="form-control-file" id="photo" >
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- CV Field -->
                <div class="mb-3">
                    <label class="form-label" for="inputEmail"></label>
                    <!-- Custom Toolbar -->


                    <!-- Quill Editor -->
                    <div id="quill-container" wire:ignore>
                        <div id="quill-editor" class="mb-3" style="height: 300px;"></div>
                    </div>

                    <!-- Hidden textarea for Livewire binding -->
                    <textarea
                        rows="3"
                        class="mb-3 d-none"
                        name="body"
                        id="quill-editor-area"
                        wire:model="cv"></textarea>

                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Governorate Field -->
                <div class="form-group mb-3">
                    <label for="governorate_id">المحافظة</label>
                    <select wire:model="governorate_id" class="form-control" id="governorate_id">
                        <option value="">اختر المحافظة</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gov->id); ?>"><?php echo e($gov->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['governorate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Active Checkbox -->
                <div class="form-check mb-3">
                    <input type="checkbox" wire:model="is_active" class="form-check-input" id="is_active">
                    <label class="form-check-label" for="is_active">Active</label>
                </div>

                <!-- Save Button -->
                <button type="submit" class="btn btn-primary">إضافة</button>
            </form>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    const toolbarOptions = [
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        // [{ 'font': [] }],

      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      ['blockquote', 'code-block'],
      [{ 'align': [] }],
      [{ 'direction': 'rtl' }],                         // text direction


      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent

    //   [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown



      ['clean']                                         // remove formatting button
    ];
        document.addEventListener('DOMContentLoaded', function() {
            if (document.getElementById('quill-editor-area')) {
                var editor = new Quill('#quill-editor', {

                    modules: {
        toolbar: toolbarOptions
      },
                    theme:'snow'
                });

                var quillEditorArea = document.getElementById('quill-editor-area');

                // Set initial content from the textarea (useful for editing existing content)
                editor.root.innerHTML = quillEditorArea.value;

                // Sync Quill editor changes to the hidden textarea
                editor.on('text-change', function() {
                    quillEditorArea.value = editor.root.innerHTML;
                    // Use Livewire to update the value
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('cv', quillEditorArea.value);
                });

                // Optional: sync textarea changes to the Quill editor (e.g., when loaded via Livewire)
                quillEditorArea.addEventListener('input', function() {
                    editor.root.innerHTML = quillEditorArea.value;
                });

                // Handle Livewire updates (for example, when editing)
                window.addEventListener('load-cv-content', event => {
                    editor.root.innerHTML = event.detail.content;
                    quillEditorArea.value = event.detail.content;
                });
            }
        });
    </script>

<?php $__env->stopPush(); ?>
<?php /**PATH D:\laravel\sar_website\resources\views/livewire/admin/candidate/add-candidate.blade.php ENDPATH**/ ?>