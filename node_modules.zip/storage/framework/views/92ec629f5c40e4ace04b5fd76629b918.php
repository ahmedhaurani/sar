<div class="container">
    <h2>Manage Requests</h2>

    <?php if($requests->isEmpty()): ?>
        <p>No requests found.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Note</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($request->id); ?></td>
                        <td><?php echo e($request->department->name); ?></td>
                        <td><?php echo e(ucfirst($request->status)); ?></td>
                        <td><?php echo e($request->note); ?></td>
                        <td>
                            <!-- Action buttons for editing or viewing -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\manage-requests.blade.php ENDPATH**/ ?>