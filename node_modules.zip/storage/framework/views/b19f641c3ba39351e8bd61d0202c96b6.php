
<div class="container mt-4">
    <h2 class="mb-4">Departments</h2>

    <?php if($departments->isEmpty()): ?>
        <div class="alert alert-info">
            No departments found. <a href="<?php echo e(route('admin.departments.add')); ?>" class="btn btn-link">Click here to add a new department.</a>
        </div>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0"><?php echo e($department->name); ?></h5>
                            <div class="mb-2">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update department')): ?>
                                <a href="<?php echo e(url('admin/departments/edit/'.$department->id )); ?>" class=" btn btn-sm btn-warning">Edit</a>
                                <?php endif; ?>
                                <button wire:click="delete(<?php echo e($department->id); ?>)" class="btn btn-sm btn-outline-danger">Delete</button>
                            </div>
                        </div>
                        <?php if($department->children->isNotEmpty()): ?>
                            <div class="card-body">
                                <h6>Sub-departments:</h6>
                                <ul class="list-unstyled ms-3">
                                    <?php $__currentLoopData = $department->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-2">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span><?php echo e($child->name); ?></span>
                                                <div class="mb-2">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update department')): ?>
                                                    <a href="<?php echo e(url('admin/departments/edit/'.$child->id )); ?>" class="btn btn-sm btn-primary">Edit</a>
                                                    <?php endif; ?>
                                                    <button wire:click="delete(<?php echo e($child->id); ?>)" class="btn btn-sm btn-link text-danger">Delete</button>
                                                </div>
                                            </div>

                                            <!-- Nested sub-departments -->
                                            <?php if($child->children->isNotEmpty()): ?>
                                                <ul class="list-unstyled ms-3">
                                                    <?php $__currentLoopData = $child->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="mb-2">
                                                            <div class="d-flex justify-content-between align-items-center">
                                                                <span><?php echo e($grandchild->name); ?></span>
                                                                <div class="mb-2">
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update department')): ?>
                                                                    <a href="<?php echo e(url('admin/departments/edit/'.$grandchild->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                                                    <?php endif; ?>
                                                                    <button wire:click="delete(<?php echo e($grandchild->id); ?>)" class="btn btn-sm btn-link text-danger">Delete</button>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.departments.add')); ?>" class="btn btn-success mt-3">Add Department</a>
</div>

<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\department\view-departments.blade.php ENDPATH**/ ?>