<div class="container my-auto mt-5">
    <?php if(session('status')): ?>
    <div class="alert alert-primary alert-dismissible fade show mt-3" role="alert">
        <i class="fas fa-check-circle"></i> <?php echo e(session('status')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>


    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Roles</h4>
            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> إضافة مجموعة
            </a>
        </div>



        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>الاجراء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($role->id); ?></td>
                        <td><?php echo e($role->name); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update role')): ?>
                            <a href="<?php echo e(route('roles.permissions', $role->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-user-shield"></i> اضافة وحذف صلاحيات
                            </a>

                            <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-sm btn-success">
                                <i class="fas fa-edit"></i> تعديل
                            </a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                            <button wire:click="confirmDelete(<?php echo e($role->id); ?>)" class="btn btn-sm btn-danger"
                                data-bs-toggle="modal"
                                data-bs-target="#modalCenter"
                                >
                                <i class="fas fa-trash"></i> حذف
                            </button>
                            <button wire:click="confirmDelete(<?php echo e($role->id); ?>)"
                                class="btn btn-sm btn-danger mx-2" data-bs-toggle="modal"
                                data-bs-target="#deleteConfirmModal">
                                <i class="fas fa-trash"></i> حذفي
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
       <!-- Modal -->
       <div wire:ignore.self class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteConfirmModalTitle">تأكيد الحذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <p>هل انت متأكد من انك تريد حذف هذه الصلاحية ؟ </p>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">اغلاق</button>
                    <button type="button" class="btn btn-primary" wire:click="deleteConfirmed">حذف</button>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->startPush('scripts'); ?>
    <?php
        $__scriptKey = '307475512-0';
        ob_start();
    ?>
<script>
    // window.addEventListener('show-delete-modal', event => {
    //     $('#deleteConfirmModal').modal('show');
    // });

    // window.addEventListener('closeDeleteModal', event => {
    //     $('#deleteConfirmModal').modal('hide');
    //     $('.modal-backdrop').remove(); // Clean up the backdrop
    //     $('body').removeClass('modal-open');
    //     $('body').removeAttr('style');
    // });
//     $wire.on('show-delete-modal', () => {

// $('#deleteConfirmModal').modal('show');

// });


$wire.on('closeModal', () => {

$('#deleteConfirmModal').modal('hide');
$('.modal').remove();
$('.modal-backdrop').remove();
$('body').removeClass('modal-open');
$('body').removeAttr('style');
});

</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

<?php $__env->stopPush(); ?>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\roles\view-roles.blade.php ENDPATH**/ ?>