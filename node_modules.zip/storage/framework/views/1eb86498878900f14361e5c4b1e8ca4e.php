<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header text-white">
            <h3 class="mb-0">إدارة الطلبات</h3> <!-- Manage Requests in Arabic -->
        </div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Table of Requests -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>رقم الطلب</th> <!-- Request ID -->
                            <th>القسم</th> <!-- Department -->
                            <th>عنوان الطلب</th> <!-- Request Title -->
                            <th>الحالة</th> <!-- Status -->
                            <th>الملاحظات</th> <!-- Notes -->
                            <th>الإجراء</th> <!-- Action -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($request->id); ?></td>
                                <td><?php echo e($request->department->name); ?></td>
                                <td><?php echo e($request->request_title); ?></td>
                                <td><?php echo e(ucfirst($request->status)); ?></td>
                                <td><?php echo e($request->note); ?></td>
                                <td>
                                    <!-- Edit Button -->
                                    <a href="<?php echo e(route('requests.edit', $request->id)); ?>" class="btn btn-sm btn-success">
                                        تعديل <!-- Edit -->
                                    </a>

                                    <!-- Delete Button with Confirmation -->
                                    <button wire:click="confirmDelete(<?php echo e($request->id); ?>)" class="btn btn-sm btn-danger mx-2">
                                        حذف <!-- Delete -->
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination (if applicable) -->
            <div class="d-flex justify-content-end">
                <?php echo e($requests->links()); ?>

            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div wire:ignore.self class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">تأكيد الحذف <!-- Confirm Deletion --></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    هل أنت متأكد أنك تريد حذف هذا الطلب؟ <!-- Are you sure you want to delete this request? -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء <!-- Cancel --></button>
                    <button type="button" wire:click="deleteRequest" class="btn btn-danger">حذف <!-- Delete --></button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add your JavaScript at the bottom of the file -->
<?php $__env->startPush('custom-scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        window.addEventListener('show-delete-confirmation', event => {
            var myModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            myModal.show();
        });

        window.addEventListener('close-modal', event => {
            var myModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
            if (myModal) {
                myModal.hide();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laravel\sar_website\resources\views\livewire\admin\request\manage-requests.blade.php ENDPATH**/ ?>